---
name: prompt-polisher
description: 将零散输入整理为可执行提示词
version: 1.2.0
author: SkillViewer Demo
tags: [prompting, writing]
---

# Prompt Polisher

## Goals

- 将碎片化需求压缩成清晰目标
- 补齐输出格式、约束条件和验收标准
- 输出一版适合直接复制使用的最终 Prompt

## Output

- 背景
- 目标
- 约束
- 输出格式
- 最终 Prompt
