---
name: brief-writer-zh
description: 将输入整理成中文简报和执行摘要
version: 0.8.2
author: SkillViewer Labs
tags: [zh-CN, brief, summary]
---

# Brief Writer ZH

## Goals

- 从原始输入提炼核心信息
- 用中文输出结构化简报
- 保持简洁、直接、可执行

## Output

- 核心结论
- 关键事实
- 机会与风险
- 建议动作
