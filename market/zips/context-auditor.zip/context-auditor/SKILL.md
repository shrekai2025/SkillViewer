---
name: context-auditor
description: 审查当前任务上下文的完整性与风险点
version: 1.0.0
author: SkillViewer Demo
tags: [analysis, safety, workflow]
---

# Context Auditor

## Goals

- 找出需求中缺失的前提条件
- 标出可能影响结果的隐含假设
- 列出还没确认的依赖与边界

## Output

给出：

- 已明确的条件
- 缺失信息
- 风险点
- 建议下一步
