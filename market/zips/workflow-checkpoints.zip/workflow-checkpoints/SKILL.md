---
name: workflow-checkpoints
description: 为长流程任务建立阶段断点与回退点
version: 0.9.0
author: SkillViewer Labs
tags: [planning, delivery, ops]
---

# Workflow Checkpoints

## Goals

- 将任务拆为 3-5 个阶段
- 为每个阶段定义“完成标准”
- 在高风险节点提示做一次状态汇报

## Output

- Phase 列表
- 每阶段完成定义
- 风险提醒
- 汇报模板
